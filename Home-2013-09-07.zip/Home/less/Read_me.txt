theme.less  &  Variables.less 
available in premium theme edition
get it  here https://creativemarket.com/artlabs
or here http://www.bootstraptor.com
follow us on twitter for updates @Bootstraptor